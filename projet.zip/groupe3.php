<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Groupe 3 Exercices</title>
    <style>
        body{
            text-align: center;
            background-color: lightskyblue;
        }
        select {
            padding: 10px;
            font-size: 16px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h2>Exercices de Groupe 3</h2>
    <li>
        <ul><a href="exercice13.php">Exercice 13</a></ul>
        <ul><a href="exercice14.php">Exercice 14</a></ul>
        <ul><a href="exercice15.php">Exercice 15</a></ul>
        <ul><a href="exercice16.php">Exercice 16</a></ul>
        <ul><a href="exercice17.php">Exercice 17</a></ul>
    </li>
</body>
</html>
