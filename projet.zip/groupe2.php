<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Groupe 2 Exercices</title>
    <style>
         body{
            text-align: center;
            background-color: lightskyblue;
        }
        
    </style>
</head>
<body>
    <h2>Exercices de Groupe 2</h2>
    <li>
        <ul><a href="exercice7.php">Exercice 7</a></ul>
        <ul><a href="exercice8.php">Exercice 8</a></ul>
        <ul><a href="exercice9.php">Exercice 9</a></ul>
        <ul><a href="exercice10.php">Exercice 10</a></ul>
        <ul><a href="exercice11.php">Exercice 11</a></ul>
        <ul><a href="exercice12.php">Exercice 12</a></ul>
    </li>
</body>
</html>
