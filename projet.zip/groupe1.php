<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Groupe 1 Exercices</title>
    <style>
        body{
            text-align: center;
            background-color: lightskyblue;
        }
        ul{
    padding: 80px;
    background-color: aqua;
    width: 21%;
    border-radius: 10px;
    box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 1);
    display: inline;
}
ul{
            color: #3498db;
            font-size: xx-large;
            padding: 30px 50px;
            border-radius: 5px;
            transition: background-color 0.3s;
            margin: 10px;
            text-decoration: none;
            border: 15px;
            font-family: 'Times New Roman', Times, serif;
            font-size: xx-large;
            display: inline;
}
ul:hover{
    background-color: #e0e0e0;
    color: orange;
    }
    </style>
</head>
<body>
    <h2>Exercices de Groupe 1</h2>
    
   
    <ul>
        <li ><a href="exercice1.php">Exercice 1</a></li>
        <li><a href="exercice2.php">Exercice 2</a></li>
        <li><a href="exercice3.php">Exercice 3</a></li>
        <li><a href="exercice4.php">Exercice 4</a></li>
        <li><a href="exercice5.php">Exercice 5</a></li>
        <li><a href="exercice6.php">Exercice 6</a></l>
    </ul>
    
</body>
</html>
